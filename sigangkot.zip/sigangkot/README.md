# SIG-Angkutan-Kota
SIGANGKOT

Aplikasi Sistem Informasi Geografis Angkutan Kota

JIKA FOLDER VENDOR HILANG GUNAKAN sigangkot.zip (https://github.com/pejamstudio/SIG-Angkutan-Kota/blob/master/sigangkot.zip)

WEB DEMO

halaman utama
https://sigangkot.000webhostapp.com/public/

halaman login
https://sigangkot.000webhostapp.com/public/login

TIPE USER

super admin:
user : iqbalul.hidayat280199@gmail.com
pass : test2801

admin kabupaten :
user :iqbalul.hidayat2801@gmail.com
pass :test2801

driver :
user : muhammad.1705124011@mhs.unesa.ac.id
pass : test2801

Anggota Kelompok:
Muhammad Iqbalul Hidayat 	    (17051204011)
Arum Dewi Ayu Safira S 		    (17051204015)
Sulistyanto Laili R 		      (17051204026)
Dedy Putra Romadhon          	(17051204060)

