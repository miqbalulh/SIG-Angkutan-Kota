<?php if(isset($data['header'])){ ?>
	<title><?= $data['header'] ?> | SIGANGKOT</title>
<?php }else{ ?>
	<title>SIGANGKOT</title>
<?php } ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>sigangkot - error 404</title>
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="<?= $GLOBALS['path'];?>/assets/vendor/bootstrap/css/bootstrap.min.css">
<link href="<?= $GLOBALS['path'];?>/assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
<link rel="stylesheet" href="<?= $GLOBALS['path'];?>/assets/libs/css/style.css">
<link rel="stylesheet" href="<?= $GLOBALS['path'];?>/assets/vendor/fonts/fontawesome/css/fontawesome-all.css">

<!-- data table -->
<link rel="stylesheet" type="text/css" href="<?= $GLOBALS['path'];?>/assets/vendor/datatables/css/dataTables.bootstrap4.css">
<link rel="stylesheet" type="text/css" href="<?= $GLOBALS['path'];?>/assets/vendor/datatables/css/buttons.bootstrap4.css">
<link rel="stylesheet" type="text/css" href="<?= $GLOBALS['path'];?>/assets/vendor/datatables/css/select.bootstrap4.css">
<link rel="stylesheet" type="text/css" href="<?= $GLOBALS['path'];?>/assets/vendor/datatables/css/fixedHeader.bootstrap4.css">


<!-- leaflet -->
<link rel="stylesheet" href="<?= $GLOBALS['path'];?>/assets/leaflet/leaflet.css"
   integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
   crossorigin=""/>
<link rel="stylesheet" href="<?= $GLOBALS['path'];?>/assets/leaflet/leaflet-locationpicker.css"/>



