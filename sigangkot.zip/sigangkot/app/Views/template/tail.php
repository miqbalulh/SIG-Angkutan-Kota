<script src="<?= $GLOBALS['path'];?>/assets/vendor/jquery/jquery-3.3.1.min.js"></script>
<!-- bootstap bundle js -->
<script src="<?= $GLOBALS['path'];?>/assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
<!-- slimscroll js -->
<script src="<?= $GLOBALS['path'];?>/assets/vendor/slimscroll/jquery.slimscroll.js"></script>
<!-- main js -->
<script src="<?= $GLOBALS['path'];?>/assets/libs/js/main-js.js"></script>
<!-- chart chartist js -->
<script src="<?= $GLOBALS['path'];?>/assets/vendor/charts/chartist-bundle/chartist.min.js"></script>
<!-- sparkline js -->
<script src="<?= $GLOBALS['path'];?>/assets/vendor/charts/sparkline/jquery.sparkline.js"></script>
<!-- morris js -->
<script src="<?= $GLOBALS['path'];?>/assets/vendor/charts/morris-bundle/raphael.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/assets/vendor/charts/morris-bundle/morris.js"></script>
<!-- chart c3 js -->
<script src="<?= $GLOBALS['path'];?>/assets/vendor/charts/c3charts/c3.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/assets/vendor/charts/c3charts/d3-5.4.0.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/assets/vendor/charts/c3charts/C3chartjs.js"></script>
<script src="<?= $GLOBALS['path'];?>/assets/libs/js/dashboard-ecommerce.js"></script>

<!-- data tabel -->
<script src="<?= $GLOBALS['path'];?>/assets/vendor/multi-select/js/jquery.multi-select.js"></script>
<script src="<?= $GLOBALS['path'];?>/js/jquery.dataTables.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/assets/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/js/dataTables.buttons.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/assets/vendor/datatables/js/buttons.bootstrap4.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/assets/vendor/datatables/js/data-table.js"></script>
<script src="<?= $GLOBALS['path'];?>/js/jszip.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/js/pdfmake.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/js/vfs_fonts.js"></script>
<script src="<?= $GLOBALS['path'];?>/js/buttons.html5.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/js/buttons.print.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/js/buttons.colVis.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/js/dataTables.rowGroup.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/js/dataTables.select.min.js"></script>
<script src="<?= $GLOBALS['path'];?>/js/dataTables.fixedHeader.min.js"></script>


<script src="<?= $GLOBALS['path'];?>/assets/leaflet/leaflet.js"
   integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
   crossorigin=""></script>
<script src="<?= $GLOBALS['path'];?>/assets/leaflet/leaflet-locationpicker.js"></script>
<script src="<?= $GLOBALS['path'];?>/assets/leaflet/leaflet.ajax.js"></script>