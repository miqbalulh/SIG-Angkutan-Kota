<?php 

require_once '../vendor/autoload.php';

require_once 'Core/Route.php';
require_once 'Core/Controller.php';


require_once 'Database.php';

$GLOBALS['path'] = '/sigangkot/public';